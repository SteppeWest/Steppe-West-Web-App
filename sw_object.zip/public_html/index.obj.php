<?php
// suggested object oriented entry script
$updated = '2024-07-12';
$canonical = 'https://steppewest.com/';
$pages = [
	'home', // first item is /
];

$appFolder = '0190888a-c7e9-7bfc-a951-6005e1293165';
if (basename(__DIR__) != 'public_html') $appFolder = '../' . $appFolder;

// Require the app.php file for functions
require __DIR__ . '/' . $appfolder . '/app.php';

// Run the app (Yii app runner used as an example)
(new yii\web\Application($config))->run();
