<?php // Kazakh
return [
	'locale' => 'kk_KZ',
	'lang' => 'kk',
	'origin' => "Бұл хат алғаш рет {Substack}-те жарияланған.",
	'footer1' => "Steppe West {GubbiGubbi} (сондай-ақ {KabiKabi} ретінде белгілі) халықтарының жерінде орналасқанымызды мойындайды.",
	'footer2' => "Steppe West коммерциялық емес кәсіпорын болып табылады және әрқашан солай болып қалады.",
	'footer3' => "Steppe West {UA} Украинаны және {PS} Палестинаны қолдайды.",
	'copy' => "Авторлық құқық © Steppe West 2024.",
];
