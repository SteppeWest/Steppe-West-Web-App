<?php
Yii::setAlias('@common',   dirname(__DIR__));
Yii::setAlias('@assets',       '@common/assets');
Yii::setAlias('@backend',  dirname(dirname(__DIR__)) . '/backend');
Yii::setAlias('@frontend', dirname(dirname(__DIR__)) . '/frontend');
Yii::setAlias('@links',    dirname(dirname(__DIR__)) . '/links');
Yii::setAlias('@members',  dirname(dirname(__DIR__)) . '/members');
//Yii::setAlias('@cdn',      dirname(dirname(__DIR__)) . '/cdn');
Yii::setAlias('@console',  dirname(dirname(__DIR__)) . '/console');
