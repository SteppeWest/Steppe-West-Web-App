<?php
return [
	'class' => 'yii\db\Connection',
	'dsn' => 'mysql:host=localhost;dbname=u746306670_sw_advanced',
	'username' => 'u746306670_sw_advanced',
	'password' => 'XMyxVaRYQyCAR3sl3EMDqa7X',
	'charset' => 'utf8',
	'tablePrefix' => 'sw_',

	// Schema cache options (for production environment)
	//'enableSchemaCache' => true,
	//'schemaCacheDuration' => 60,
	//'schemaCache' => 'cache',
];
