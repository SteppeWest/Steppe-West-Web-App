<?php
return [
	'enablePrettyUrl' => true,
	'showScriptName' => false,
	'enableStrictParsing' => false,
	'rules' => [
	],
];
