<?php
return [
];
	//'class' => 'yii\db\Connection',
	//'dsn' => 'mysql:host=localhost;dbname=u746306670_sw_basic',
	//'username' => 'u746306670_sw_basic',
	//'password' => 'XMyxVaRYQyCAR3sl3EMDqa7X',
	//'charset' => 'utf8',
	//'tablePrefix' => 'sw_', // Add this line to set the table prefix

	// Schema cache options (for production environment)
	//'enableSchemaCache' => true,
	//'schemaCacheDuration' => 60,
	//'schemaCache' => 'cache',
