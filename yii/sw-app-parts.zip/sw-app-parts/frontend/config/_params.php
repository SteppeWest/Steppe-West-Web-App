<?php
return [
	'adminEmail' => 'pedro@steppewest.com',
];
