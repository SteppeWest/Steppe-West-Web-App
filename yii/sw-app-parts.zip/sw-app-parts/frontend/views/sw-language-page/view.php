<?php

use yii\helpers\Html;
use yii\widgets\DetailView;

/** @var yii\web\View $this */
/** @var common\models\SWCurrentLanguage $model */

$this->title = $page->title;
$this->params['breadcrumbs'][] = ['label' => 'SW Current Languages', 'url' => ['index']];
$this->params['breadcrumbs'][] = $this->title;
\yii\web\YiiAsset::register($this);
?>
<div class="swcurrent-language-view">
	<h1><?= Html::encode($this->title) ?></h1>

	<div><?= $page->content ?></div>
</div>
