<?php
return [
	'name' => "O‘zbek",
	'code' => "UZ",
	'lang' => "uz",
	'locale' => "uz_UZ",
	'description' => "Markaziy Osiyoning boy va rang-barang musiqasi va madaniyatlarini ingliz tilida so'zlashuvchi dunyoga namoyish qilish.",
	'keywords' => "Markaziy Osiyo, Qozog'iston, Qirg'iziston, Tojikiston, Turkmaniston, O'zbekiston, Ozarbayjon, Mo'g'uliston, Turklar, Yakut, Saha, Tuva, Sibir, Mo'g'ullar, Ozarbayjon musiqasi, Qozog'iston musiqasi, Qirg'iziston musiqasi, Mo'g'uliston musiqasi, Tojikiston musiqasi, Turkmaniston musiqasi, O'zbekiston musiqasi, Markaziy Osiyo musiqasi, Turk musiqasi, Mo'g'uliston musiqasi, Yakut musiqasi, Saha musiqasi, Tuva musiqasi, Sibir musiqasi, Ozarbayjon madaniyati, Qozog'iston madaniyati, Qirg'iziston madaniyati, Mo'g'uliston madaniyati, Tojikiston madaniyati, Turkmaniston madaniyati, O'zbekiston madaniyati, Markaziy Osiyo madaniyati, Turk madaniyati, Mo'g'uliston madaniyati, Yakut madaniyati, Saha madaniyati, Tuva madaniyati, Sibir madaniyati, Markaziy Osiyo yangiliklari, Ozarbayjon yangiliklari, Qozog'iston yangiliklari, Qirg'iziston yangiliklari, Mo'g'uliston yangiliklari, Tojikiston yangiliklari, Turkmaniston yangiliklari, O'zbekiston yangiliklari, Turk yangiliklari, Mo'g'uliston yangiliklari, Yakut yangiliklari, Saha yangiliklari, Tuva yangiliklari, Sibir yangiliklari, Ozarbayjon san'ati, Qozog'iston san'ati, Qirg'iziston san'ati, Mo'g'uliston san'ati, Tojikiston san'ati, Turkmaniston san'ati, O'zbekiston san'ati, Markaziy Osiyo san'ati, Turk san'ati, Mo'g'uliston san'ati, Yakut san'ati, Saha san'ati, Tuva san'ati, Sibir san'ati",
	'origin' => "Bu xat dastlab {Substack}-da e'lon qilingan.",
	'footer1' => "Steppe West biz joylashgan {GubbiGubbi} (shuningdek, {KabiKabi} nomi bilan tanilgan) xalqini tan oladi.",
	'footer2' => "Steppe West notijorat korxona bo'lib, har doim shunday bo'ladi.",
	'footer3' => "Steppe West {UA} Ukraina va {PS} Falastinni qo'llab-quvvatlaydi.",
	'copy' => "Mualliflik huquqi © Steppe West 2024.",
];
