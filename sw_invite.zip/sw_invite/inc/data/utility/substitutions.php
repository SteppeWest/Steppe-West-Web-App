<?php
return [
	'Substack' => [
		'url' => 'steppewest.substack.com/p/steppe-wests-invitation',
		'title' => 'Substack',
		'label' => '<i class="bi bi-substack"></i> Substack',
	],
	'GubbiGubbi' => [
		'url' => 'gubbigubbidyungungoo.com/',
		'title' => 'Gubbi Gubbi',
		'label' => 'Gubbi Gubbi',
	],
	'KabiKabi' => [
		'url' => 'gubbigubbidyungungoo.com/explanation-of-the-gubbi-gubbi-language/',
		'title' => 'Kabi Kabi',
		'label' => 'Kabi Kabi',
	],
];
