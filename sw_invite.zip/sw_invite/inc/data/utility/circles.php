<?php
return [
	'animals_and_wildlife' => 'Wildlife in Central Asia',
	'architecture' => 'Architectural Marvel in Central Asia',
	'arts_and_crafts' => 'Central Asian Arts and Crafts',
	'cuisine' => 'Traditional Central Asian Cuisine',
	'festivals_and_celebrations' => 'Central Asian Festival Celebration',
	'landscapes' => 'A Beautiful Landscape in Central Asia',
	'markets_and_bazaars' => 'Bustling Market in Central Asia',
	'modern_life' => 'Modern Life in Central Asia',
	'people_and_culture' => 'People in Traditional Central Asian Attire',
	'religion_and_spirituality' => 'Religious Site in Central Asia',
];
