<div class="container my-1">
	<div class="row justify-content-center">
		<div class="col-lg-8 fw-bolder text-center">
			<?= renderLanguageButtons() ?>
		</div>
	</div>
	<div class="row justify-content-center">
		<div class="col-lg-8 text-center">
			<?= renderFaq() ?>
		</div>
	</div>
</div>
