<?php
return [
	'name' => "Тоҷикӣ",
	'code' => "TJ",
	'locale' => "tg_TJ",
	'origin' => "Ин нома аслан дар {Substack} нашр шудааст.",
	'footer1' => "Steppe West мардумони {GubbiGubbi} (чунин маъруф бо {KabiKabi}), ки мо дар замини онҳо қарор дорем, эътироф мекунад.",
	'footer2' => "Steppe West як корхонаи ғайритиҷоратӣ мебошад ва ҳамеша чунин хоҳад монд.",
	'footer3' => "Steppe West бо {UA} Украина ва {PS} Фаластин ҳамраъй аст.",
	'copy' => "Ҳуқуқи муаллиф © Steppe West 2024.",
];
