<?php
return [
	'name' => "Türkmen",
	'code' => "TM",
	'locale' => "tk_TM",
	'origin' => "Bu hat ilkinji gezek {Substack}-de neşir edildi.",
	'footer1' => "Steppe West ýerleşýän ýerimiz {GubbiGubbi} ({KabiKabi} diýip hem tanalýar) halklarynyň ýeridigiğini kabul edýär.",
	'footer2' => "Steppe West girdeji gazanmaga gönükdirilmedik kärhana bolup durýar we hemişe şeýle bolar.",
	'footer3' => "Steppe West {UA} Ukraina we {PS} Palestinanyň ýanyndadyr.",
	'copy' => "Awtorlyk hukuklary © Steppe West 2024.",
];
