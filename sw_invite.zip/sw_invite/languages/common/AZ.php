<?php
return [
	'name' => "Azərbaycan",
	'code' => "AZ",
	'locale' => "az_AZ",
	'origin' => "Bu məktub əvvəlcə {Substack}-də dərc edilmişdir.",
	'footer1' => "Steppe West, üzərində yerləşdiyimiz {GubbiGubbi} (həmçinin {KabiKabi} kimi tanınır) xalqını tanıyır.",
	'footer2' => "Steppe West qeyri-kommersiya müəssisəsidir və həmişə belə olacaq.",
	'footer3' => "Steppe West {UA} Ukraynanı və {PS} Fələstini dəstəkləyir.",
	'copy' => "Müəllif hüququ © Steppe West 2024.",
];
