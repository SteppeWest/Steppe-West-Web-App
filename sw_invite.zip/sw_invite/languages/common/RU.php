<?php
return [
	'name' => "Русский",
	'code' => "RU",
	'locale' => "ru_RU",
	'origin' => "Это письмо было первоначально опубликовано на {Substack}.",
	'footer1' => "Steppe West признает народ {GubbiGubbi} (также известный как {KabiKabi}), на земле которых мы находимся.",
	'footer2' => "Steppe West является и всегда будет некоммерческим предприятием.",
	'footer3' => "Steppe West поддерживает {UA} Украину и {PS} Палестину.",
	'copy' => "Авторское право © Steppe West 2024.",
];
