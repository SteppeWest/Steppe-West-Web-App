# SW Invite File Tree

* Comments on folders or files relate to the item itself.
* Comments inside folders relate to the folder contents.

#### Existing

```tree
/
├─ inc/
│  ├─ data/
│  │  ├─ // data of a utilitarian nature
│  │  ├─ circles.php
│  │  ├─ resources.php
│  │  ├─ rowData.php
│  │  ├─ socials.php
│  │  └─ substitutions.php
│  ├─ partials/
│  │  ├─ // calling these views is better IMO
│  │  ├─ content.min.php
│  │  ├─ content.php
│  │  ├─ footer.min.php
│  │  ├─ footer.php
│  │  ├─ head.min.php
│  │  ├─ head.php
│  │  ├─ header.min.php
│  │  ├─ header.php
│  │  ├─ languages.min.php
│  │  ├─ languages.php
│  │  ├─ signature.min.php
│  │  └─ signature.php
│  └─ app.php // the logic
├─ languages/
│  ├─ common/
│  │  ├─ // language data not part of a page body
│  │  ├─ AZ.php
│  │  ├─ EN.php
│  │  ├─ KG.php
│  │  ├─ KZ.php
│  │  ├─ MN.php
│  │  ├─ RU.php
│  │  ├─ TJ.php
│  │  ├─ TM.php
│  │  ├─ TR.php
│  │  └─ UZ.php
│  ├─ content/
│  │  ├─ // language data for the invite page body
│  │  ├─ AZ.php
│  │  ├─ EN.php
│  │  ├─ KG.php
│  │  ├─ KZ.php
│  │  ├─ MN.php
│  │  ├─ RU.php
│  │  ├─ TJ.php
│  │  ├─ TM.php
│  │  ├─ TR.php
│  │  └─ UZ.php
│  └─ faq/
│     ├─ // language data for the FAQ page body
│     ├─ AZ.php
│     ├─ EN.php
│     ├─ KG.php
│     ├─ KZ.php
│     ├─ MN.php
│     ├─ RU.php
│     ├─ TJ.php
│     ├─ TM.php
│     ├─ TR.php
│     └─ UZ.php
├─ ui/
│  ├─ // all of the static content
│  ├─ css/
│  │  └─ // css files
│  ├─ ico/
│  │  └─  ico files
│  ├─ img/
│  │  └─  img files
│  └─ js/
│     └─  js files
├─ .htaccess
├─ browserconfig.xml
├─ index.max.php
├─ index.min.php
└─ index.php
```

#### Proposed

```tree
/
├─ inc/
│  ├─ data/
│  │  ├─ common/
│  │  │  ├─ // language data not part of a page body
│  │  │  ├─ AZ.php
│  │  │  ├─ EN.php
│  │  │  ├─ KG.php
│  │  │  ├─ KZ.php
│  │  │  ├─ MN.php
│  │  │  ├─ RU.php
│  │  │  ├─ TJ.php
│  │  │  ├─ TM.php
│  │  │  └─ UZ.php
│  │  ├─ faq/
│  │  │  ├─// language data for the FAQ page body
│  │  │  ├─ AZ.php
│  │  │  ├─ EN.php
│  │  │  ├─ KG.php
│  │  │  ├─ KZ.php
│  │  │  ├─ MN.php
│  │  │  ├─ RU.php
│  │  │  ├─ TJ.php
│  │  │  ├─ TM.php
│  │  │  └─ UZ.php
│  │  ├─ invite/
│  │  │  ├─ // language data for the invite page body
│  │  │  ├─ AZ.php
│  │  │  ├─ EN.php
│  │  │  ├─ KG.php
│  │  │  ├─ KZ.php
│  │  │  ├─ MN.php
│  │  │  ├─ RU.php
│  │  │  ├─ TJ.php
│  │  │  ├─ TM.php
│  │  │  └─ UZ.php
│  │  └─ utility/
│  │     ├─ // data of a utilitarian nature
│  │     ├─ circles.php
│  │     ├─ resources.php
│  │     ├─ rowData.php
│  │     ├─ socials.php
│  │     └─ substitutions.php
│  ├─ views/
│  │  ├─ // what were called partials
│  │  ├─ content.min.php
│  │  ├─ content.php
│  │  ├─ footer.min.php
│  │  ├─ footer.php
│  │  ├─ head.min.php
│  │  ├─ head.php
│  │  ├─ header.min.php
│  │  ├─ header.php
│  │  ├─ languages.min.php
│  │  ├─ languages.php
│  │  ├─ signature.min.php
│  │  └─ signature.php
│  └─ app.php
├─ languages/
├─ ui/
│  ├─ // all of the static content
│  ├─ css/
│  │  └─ // css files
│  ├─ ico/
│  │  └─  ico files
│  ├─ img/
│  │  └─  img files
│  └─ js/
│     └─  js files
├─ .htaccess
├─ browserconfig.xml
├─ index.max.php
├─ index.min.php
└─ index.php
```



