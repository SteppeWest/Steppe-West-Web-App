<?php
return [
	'name' => "Türkçe",
	'code' => "TR",
	'flag' => "TR",
	'lang' => "tr",
	'locale' => "tr_TR",
	'origin' => "Bu mektup ilk olarak {Substack} üzerinde yayımlandı.",
	'footer1' => "Steppe West, üzerinde bulunduğumuz toprakların sahibi olan {GubbiGubbi} (diğer adıyla {KabiKabi}) halklarını tanır.",
	'footer2' => "Steppe West, kâr amacı gütmeyen bir girişimdir ve her zaman öyle olacaktır.",
	'footer3' => "Steppe West, {UA} Ukrayna ve {PS} Filistin ile dayanışma içindedir.",
	'copy' => "Telif Hakkı © Steppe West 2024.",
];
