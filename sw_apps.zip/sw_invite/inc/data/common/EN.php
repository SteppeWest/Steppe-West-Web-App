<?php
return [
	'name' => "English",
	'code' => "EN",
	'flag' => "GB",
	'lang' => "en_AU",
	'locale' => "en_AU",
	'origin' => "This letter was originally published on {Substack}.",
	'footer1' => "Steppe West acknowledges the {GubbiGubbi} (also known as the {KabiKabi}) peoples, on whose land we are based.",
	'footer2' => "Steppe West is, & always will be, a not for profit enterprise.",
	'footer3' => "Steppe West stands with {UA} Ukraine & {PS} Palestine.",
	'copy' => "Copyright © Steppe West 2024.",
];
