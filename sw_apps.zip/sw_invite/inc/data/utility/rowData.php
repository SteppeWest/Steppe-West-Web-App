<?php
return [
	'animals_and_wildlife' => [
		'alt' => 'Wildlife in Central Asia',
		'count' => 14,
	],
	'architecture' => [
		'alt' => 'Architectural Marvel in Central Asia',
		'count' => 14,
	],
	'arts_and_crafts' => [
		'alt' => 'Central Asian Arts and Crafts',
		'count' => 14,
	],
	'cuisine' => [
		'alt' => 'Traditional Central Asian Cuisine',
		'count' => 14,
	],
	'festivals_and_celebrations' => [
		'alt' => 'Central Asian Festival Celebration',
		'count' => 14,
	],
	'landscapes' => [
		'alt' => 'A Beautiful Landscape in Central Asia',
		'count' => 14,
	],
	'markets_and_bazaars' => [
		'alt' => 'Bustling Market in Central Asia',
		'count' => 14,
	],
	'modern_life' => [
		'alt' => 'Modern Life in Central Asia',
		'count' => 13,
	],
	'people_and_culture' => [
		'alt' => 'People in Traditional Central Asian Attire',
		'count' => 14,
	],
	'religion_and_spirituality' => [
		'alt' => 'Religious Site in Central Asia',
		'count' => 13,
	],
];
