<footer class="py-4 bg-dark">
	<div class="container">
		<?= renderFooterContent() ?>
	</div>
</footer>
<!-- Bootstrap core JS-->
<?= renderResources('js') ?>
