<footer class="bg-dark py-4"><div class="container"><?=renderFooterContent()?></div></footer><?=renderResources('js')?>
