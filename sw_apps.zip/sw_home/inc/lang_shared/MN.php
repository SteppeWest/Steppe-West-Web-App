<?php
return [
	'name' => "Монгол",
	'locale' => "mn_MN",
	'origin' => "Энэ захидал анх {Substack} дээр нийтлэгдсэн.",
	'footer1' => "Steppe West бидний суурьшсан газар болох {GubbiGubbi} (мөн {KabiKabi} гэж нэрлэдэг) ард түмнийг хүлээн зөвшөөрдөг.",
	'footer2' => "Steppe West ашгийн бус байгууллага бөгөөд үргэлж тийм байх болно.",
	'footer3' => "Steppe West {UA} Украин болон {PS} Палестинтай хамт байна.",
	'copy' => "Зохиогчийн эрх © Steppe West 2024.",
];
