<?php
return [
	'name' => "O‘zbek",
	'locale' => "uz_UZ",
	'origin' => "Bu xat dastlab {Substack}-da e'lon qilingan.",
	'footer1' => "Steppe West biz joylashgan {GubbiGubbi} (shuningdek, {KabiKabi} nomi bilan tanilgan) xalqini tan oladi.",
	'footer2' => "Steppe West notijorat korxona bo'lib, har doim shunday bo'ladi.",
	'footer3' => "Steppe West {UA} Ukraina va {PS} Falastinni qo'llab-quvvatlaydi.",
	'copy' => "Mualliflik huquqi © Steppe West 2024.",
];
