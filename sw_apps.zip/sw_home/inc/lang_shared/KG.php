<?php
return [
	'name' => "Кыргыз",
	'locale' => "ky_KG",
	'origin' => "Бул кат башында {Substack}-та жарыяланган.",
	'footer1' => "Steppe West биз жайгашкан {GubbiGubbi} (ошондой эле {KabiKabi} деп белгилүү) элинин жерин тааныйт.",
	'footer2' => "Steppe West коммерциялык эмес ишкана болуп саналат жана ар дайым ошондой бойдон калат.",
	'footer3' => "Steppe West {UA} Украинаны жана {PS} Палестинаны колдойт.",
	'copy' => "Автордук укук © Steppe West 2024.",
];
