<div class="container my-1"><div class="justify-content-center row"><div class="col-lg-8 fw-bolder text-center"><?=languageButtons($languages,$languageCode)?></div></div></div>
