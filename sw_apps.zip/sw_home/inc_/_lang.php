<div class="container my-4">
	<div class="row align-items-center justify-content-center">
		<div class="col-lg-8">
			<p class="lead">LEAD</p>
		</div>
	</div>
	<div class="row align-items-center justify-content-center">
		<div class="col-lg-1">&nbsp;</div>
		<div class="col-lg-6">
			<h4>HEADING01</h4>
			<p>PARAGRAPH01</p>
		</div>
		<div class="col-lg-3">
			<img class="img-fluid rounded-circle" alt="central_asia_04" src="ui/img/circles/central_asia_04.jpeg">
		</div>
	</div>
	<div class="row align-items-center justify-content-center">
		<div class="col-lg-3">
			<img class="img-fluid rounded-circle" alt="central_asia_09" src="ui/img/circles/central_asia_09.jpeg">
		</div>
		<div class="col-lg-6">
			<h4>HEADING02</h4>
			<p>PARAGRAPH02</p>
		</div>
		<div class="col-lg-1">&nbsp;</div>
	</div>
	<div class="row align-items-center justify-content-center">
		<div class="col-lg-1">&nbsp;</div>
		<div class="col-lg-6">
			<h4>HEADING03</h4>
			<p>PARAGRAPH03</p>
		</div>
		<div class="col-lg-3">
			<img class="img-fluid rounded-circle" alt="central_asia_10" src="ui/img/circles/central_asia_10.jpeg">
		</div>
	</div>
	<div class="row align-items-center justify-content-center">
		<div class="col-lg-3">
			<img class="img-fluid rounded-circle" alt="central_asia_19" src="ui/img/circles/central_asia_19.jpeg">
		</div>
		<div class="col-lg-6">
			<h4>HEADING04</h4>
			<p>PARAGRAPH04</p>
		</div>
		<div class="col-lg-1">&nbsp;</div>
	</div>
	<div class="row align-items-center justify-content-center">
		<div class="col-lg-1">&nbsp;</div>
		<div class="col-lg-6">
			<h4>HEADING05</h4>
			<p>PARAGRAPH05</p>
		</div>
		<div class="col-lg-3">
			<img class="img-fluid rounded-circle" alt="central_asia_17" src="ui/img/circles/central_asia_17.jpeg">
		</div>
	</div>
	<div class="row align-items-center justify-content-center">
		<div class="col-lg-3">
			<img class="img-fluid rounded-circle" alt="central_asia_11" src="ui/img/circles/central_asia_11.jpeg">
		</div>
		<div class="col-lg-6">
			<h4>HEADING06</h4>
			<p>PARAGRAPH06</p>
		</div>
		<div class="col-lg-1">&nbsp;</div>
	</div>
	<div class="row align-items-center justify-content-center">
		<div class="col-lg-1">&nbsp;</div>
		<div class="col-lg-6">
			<h4>HEADING07</h4>
			<p>PARAGRAPH07</p>
		</div>
		<div class="col-lg-3">
			<img class="img-fluid rounded-circle" alt="central_asia_16" src="ui/img/circles/central_asia_16.jpeg">
		</div>
	</div>
	<div class="row align-items-center justify-content-center">
		<div class="col-lg-3">
			<img class="img-fluid rounded-circle" alt="central_asia_15" src="ui/img/circles/central_asia_15.jpeg">
		</div>
		<div class="col-lg-6">
			<p>CLOSING</p>
			<p>SIGNATURE</p>
		</div>
		<div class="col-lg-1">&nbsp;</div>
	</div>
</div>
