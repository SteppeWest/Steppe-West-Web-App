<footer class="py-4 bg-dark">
	<div class="container">
		<p class="m-0 text-center text-white">Steppe West acknowleges the <a class="text-info" href="https://gubbigubbidyungungoo.com/" title="Gubbi Gubbi" target="_blank">Gubbi Gubbi</a> (<a class="text-info" href="https://gubbigubbidyungungoo.com/explanation-of-the-gubbi-gubbi-language/" title="Gubbi Gubbi" target="_blank">also known as</a> the <a class="text-info" href="https://www.kabikabination.com.au/" title="Kabi Kabi" target="_blank">Kabi Kabi</a>) peoples, on whose land we are based.</p>
		<p class="m-0 text-center text-white">Steppe West is, &amp; always will be, a not for profit enterprise. Steppe West stands with 🇺🇦 Ukraine &amp; 🇵🇸 Palestine.</p>
		<p class="m-0 text-center text-white">Copyright &copy; Steppe West 2024</p>		</div>
	</div>
</footer>
