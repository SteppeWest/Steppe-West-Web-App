<div class="container my-4">
	<div class="row justify-content-center">
		<div class="col-lg-8">
			<img class="img-fluid" alt="Steppe West 🇰🇿 🇰🇬 🇹🇯 🇹🇲 🇺🇿 🇲🇳 🇦🇿" src="/ui/img/flags-banner-1004x0200.png">
		</div>
	</div>
	<div class="row align-items-end justify-content-center">
		<div class="col-lg-4">
			<p class="float-start">Email: pedro@steppewest.com<br>WhatsApp, Telegram, Viber: +61400473376</p>
		</div>
		<div class="col-lg-4 float-end">
			<p class="float-end fs-2">
				<?= socialButtons($socials, 'secondary') ?>
			</p>
		</div>
	</div>
</div>
