<?php
/**
 * app/frontend/config/bootstrap.php
 */
