<?php
/**
 * app/frontend/config/params.php
 */
return [
];
