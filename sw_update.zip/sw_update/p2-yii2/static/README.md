# @static

This folder contains static files for assets.

The folder & file patterns is

```tree
@static/
├─ AnAmazingAsset/
│  ├─ {{resource type folders as needed}}
│  ├─ css/
│  ├─ ico/
│  ├─ img/
│  ├─ js/
│  └─ svg/
├─ AnotherAwesomeAsset/
│  ├─ {{resource type folders as needed}}
│  ├─ css/
│  ├─ ico/
│  ├─ img/
│  ├─ js/
│  └─ svg/
├─ ...

```
