<?php
/**
 * app/common/config/test-local.php
 */
return [
	'components' => [
		'db' => [
			'dsn' => 'mysql:host=localhost;dbname=yii2advanced_test',
		],
	],
];
