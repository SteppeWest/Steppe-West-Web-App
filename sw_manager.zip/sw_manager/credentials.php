#!/usr/bin/env php
<?php
// sw_manager/credentials.php
// Non-secret bits only

// SSH
if (!defined('SSH_ALIAS')) {
	define('SSH_ALIAS',      'steppewest');
	define('SSH_USER',       'u746306670');
	define('SSH_HOST',       '157.173.208.239');
	define('SSH_PORT',        65002);
	define('SSH_REMOTE_DIR', 'domains/steppewest.com');
}

// DB
if (!defined('DB_HOST')) {
	define('DB_HOST', 'localhost');
	define('DB_USER', 'u746306670_sw');
	define('DB_NAME', 'u746306670_sw');
	define('DB_PASS', '6EpWZubb0aHji5ctLFqcBQXWkJ99aG8DxXYhe326');
}
